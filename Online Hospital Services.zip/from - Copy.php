<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','db_conncet');

// get the post records
$txtName = $_POST['txtName'];
$txtNumber = $_POST['txtNumber'];
$txtEmail = $_POST['txtEmail'];

// database insert SQL code
$sql = "INSERT INTO `tbl_contact` ( `Name`, `Number`, `Email`) VALUES ('$txtName', '$txtNumber', '$txtEmail')";

// insert in database 
$rs = mysqli_query($con, $sql);

if($rs)
{
	echo "Contact Records Inserted";
}

?>