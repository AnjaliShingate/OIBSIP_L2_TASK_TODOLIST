<?php
// database connection code
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');

$con = mysqli_connect('localhost', 'root', '','hospital');

// get the post records
$txtcomment = $_POST['txtcomment'];

// database insert SQL code
$sql = "INSERT INTO `ajinkyatara` ( `comment`) VALUES ('$txtcomment')";

// insert in database 
$rs = mysqli_query($con, $sql);

if($rs)
{
	echo "Contact Records Inserted";
}

?>
